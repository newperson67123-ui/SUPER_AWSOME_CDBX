#!/bin/sh
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# 1. Install custom binaries to /usr/bin
for f in "$SCRIPT_DIR"/bin/*; do
  [ -f "$f" ] || continue
  name="$(basename "$f")"
  cp "$f" "/usr/bin/$name"
  chmod 755 "/usr/bin/$name"
done

# 2. Install startup script
mkdir -p "$HOME/.config/cdbx"
cp "$SCRIPT_DIR/etc/cdbx/startup.sh" "$HOME/.config/cdbx/startup.sh"
chmod 755 "$HOME/.config/cdbx/startup.sh"

# 3. Ensure zsh is installed on Alpine if apk is available
if command -v apk >/dev/null 2>&1 && ! command -v zsh >/dev/null 2>&1; then
  apk add --no-cache zsh || true
fi

# 4. Add hook to ~/.zshrc (and ~/.profile if needed) once
HOOK_BLOCK="$(cat "$SCRIPT_DIR/etc/cdbx/hook.sh")"
for rc in "$HOME/.zshrc" "$HOME/.profile"; do
  touch "$rc"
  if ! grep -q "SUPER_AWSOME_CDBX STARTUP" "$rc"; then
    printf "\n%s\n" "$HOOK_BLOCK" >> "$rc"
  fi
done

# 5. Prefer zsh for interactive shells if installed
if command -v zsh >/dev/null 2>&1; then
  if [ -f /etc/passwd ] && grep -q "^root:" /etc/passwd; then
    sed -i 's|^\(root:.*:\)[^:]*$|\1/bin/zsh|' /etc/passwd 2>/dev/null || true
  fi
fi

echo "SUPER_AWSOME_CDBX installed! Open a new shell or run: exec zsh -l"
