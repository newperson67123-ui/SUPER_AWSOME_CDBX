#!/bin/sh

# Mount /proc if missing (helpful on iSH)
[ -d /proc/1 ] || mount proc /proc -t proc 2>/dev/null || true

INIT_FLAG="$HOME/.cdbx_initialized"

if [ ! -f "$INIT_FLAG" ]; then
  printf "\n========================================\n"
  printf "  Welcome to SUPER_AWSOME_CDBX! (1st Run)\n"
  printf "========================================\n\n"

  if command -v fetch >/dev/null 2>&1; then
    fetch
  fi

  printf "Tip: Type 'fetch' anytime to check system info.\n"
  printf "Press Enter to finish first-time setup..."
  read -r _ </dev/tty 2>/dev/null || true

  touch "$INIT_FLAG"
fi
