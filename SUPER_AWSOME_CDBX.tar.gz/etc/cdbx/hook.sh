# >>> SUPER_AWSOME_CDBX STARTUP >>>
if [ -f "$HOME/.config/cdbx/startup.sh" ]; then
  . "$HOME/.config/cdbx/startup.sh"
fi
# <<< SUPER_AWSOME_CDBX END <<<
